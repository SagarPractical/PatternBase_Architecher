using ExamSystem.Data;
using ExamSystem.Repositories;
using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

var builder = WebApplication.CreateBuilder(args);

// Register services in the DI container
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("Connection")));

// Register repositories with dependency injection
builder.Services.AddScoped<ICandidateRepository, CandidateRepository>();
builder.Services.AddScoped<IExamRepository, ExamRepository>();
builder.Services.AddScoped<IQuestionRepository, QuestionRepository>();
builder.Services.AddScoped<IExamResultRepository, ExamResultRepository>();

// Add controllers with views (MVC pattern)
builder.Services.AddControllersWithViews();

builder.Services.AddDistributedMemoryCache();  // Add an in-memory cache to store session data
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30);  // Set session timeout
    options.Cookie.HttpOnly = true;  // Makes the session cookie HttpOnly
    options.Cookie.IsEssential = true;  // Required for GDPR compliance
});


var app = builder.Build();

// Configure the HTTP request pipeline

if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage(); // Show detailed errors in development
}
else
{
    app.UseExceptionHandler("/Home/Error"); // Handle exceptions in production
    app.UseHsts(); // Use HTTP Strict Transport Security in production
}

app.UseHttpsRedirection(); // Ensure all requests are redirected to HTTPS
app.UseStaticFiles(); // Serve static files like CSS, JavaScript, images

// Set up routing
app.UseRouting(); // Configure the routing middleware

app.UseSession();

// Authentication and authorization (if needed)
app.UseAuthorization();

// Default route configuration (e.g., {controller=Home}/{action=Index}/{id?})
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Account}/{action=Login}/{id?}");

// Optional: Configure custom routes

// Custom route for viewing a specific exam (e.g., /exam/1)
app.MapControllerRoute(
    name: "exam",
    pattern: "exam/{examId}",
    defaults: new { controller = "Exam", action = "StartExam" });

// Custom route for viewing exam results (e.g., /exam/1/results)
app.MapControllerRoute(
    name: "results",
    pattern: "exam/{examId}/results",
    defaults: new { controller = "Exam", action = "ExamReport" });

app.MapControllerRoute(
        name: "deleteQuestion",
        pattern: "Questions/Delete/{id}",
        defaults: new { controller = "Questions", action = "Delete" });


// Run the application
app.Run();

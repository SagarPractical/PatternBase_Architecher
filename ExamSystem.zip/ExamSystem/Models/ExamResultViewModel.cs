﻿namespace ExamSystem.Models
{
    public class ExamResultViewModel
    {
        public string CandidateName { get; set; }
        public string ExamTitle { get; set; }
        public int Score { get; set; }
        public int TotalMarks { get; set; }
    }

}

﻿namespace ExamSystem.Models
{
    public class ExamAttemptViewModel
    {
        public Exam Exam { get; set; }
        public List<Question> Questions { get; set; }
        public Dictionary<int, string> Answers { get; set; }
        public int CurrentQuestionIndex { get; set; } // Track the index of the current question
    }


}

﻿using System.ComponentModel.DataAnnotations;

namespace ExamSystem.Models
{
    public class Question
    {
        public int ID { get; set; }

        [Required(ErrorMessage = "Exam ID is required.")]
        public int ExamID { get; set; }

        [Required(ErrorMessage = "Question Text is required.")]
        public string QuestionText { get; set; }

        [Required(ErrorMessage = "Option A is required.")]
        public string OptionA { get; set; }

        [Required(ErrorMessage = "Option B is required.")]
        public string OptionB { get; set; }

        [Required(ErrorMessage = "Option C is required.")]
        public string OptionC { get; set; }

        [Required(ErrorMessage = "Option D is required.")]
        public string OptionD { get; set; }

        [Required(ErrorMessage = "Correct Answer is required.")]
        [RegularExpression(@"^[A-D]$", ErrorMessage = "Correct Answer must be one of A, B, C, or D.")]
        public string CorrectAnswer { get; set; }
    }
}

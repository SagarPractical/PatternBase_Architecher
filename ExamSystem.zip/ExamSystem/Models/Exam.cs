﻿using System.ComponentModel.DataAnnotations;

namespace ExamSystem.Models
{
    public class Exam
    {
        public int ID { get; set; }

        [Required(ErrorMessage = "Exam Title is required.")]
        public string Title { get; set; }

        [Required(ErrorMessage = "Duration is required.")]
        [Range(1, int.MaxValue, ErrorMessage = "Duration must be greater than zero.")]
        public int Duration { get; set; }

        [Required(ErrorMessage = "Total Marks are required.")]
        [Range(1, int.MaxValue, ErrorMessage = "Total Marks must be greater than zero.")]
        public int TotalMarks { get; set; }
    }
}

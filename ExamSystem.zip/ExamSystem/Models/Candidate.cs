﻿namespace ExamSystem.Models
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    public class Candidate
    {
        public int ID { get; set; }

        [Required(ErrorMessage = "Name is required.")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Email is required.")]
        [EmailAddress(ErrorMessage = "Invalid email format.")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Mobile is required.")]
        [Phone(ErrorMessage = "Invalid mobile number.")]
        [StringLength(10, ErrorMessage = "Mobile number must be 10 digits.", MinimumLength = 10)]
        public string Mobile { get; set; }

        [Required(ErrorMessage = "Password is required.")]
        [RegularExpression(@"^.{5,}$", ErrorMessage = "Password must be at least 5 characters long.")]
        public string Password { get; set; }


        [Required(ErrorMessage = "Date of Birth is required.")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}")]
        public DateTime DateOfBirth { get; set; }

        // Display age in the view (readonly, can be computed in the controller)
        public int Age => DateTime.Now.Year - DateOfBirth.Year;
    }


}

﻿using System.ComponentModel.DataAnnotations;

namespace ExamSystem.Models
{
    public class ExamResult
    {
        public int ID { get; set; }

        [Required(ErrorMessage = "Exam ID is required.")]
        public int ExamID { get; set; }

        [Required(ErrorMessage = "Candidate ID is required.")]
        public int CandidateID { get; set; }

        [Required(ErrorMessage = "Score is required.")]
        [Range(0, int.MaxValue, ErrorMessage = "Score must be a non-negative value.")]
        public int Score { get; set; }
    }

}

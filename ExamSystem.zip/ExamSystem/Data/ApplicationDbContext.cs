﻿using ExamSystem.Models;
using Microsoft.EntityFrameworkCore;

namespace ExamSystem.Data
{
    public class ApplicationDbContext : DbContext
    {
        public DbSet<Candidate> Candidate { get; set; }
        public DbSet<Exam> Exam { get; set; }
        public DbSet<Question> Question { get; set; }
        public DbSet<ExamResult> ExamResult { get; set; }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        { }
    }

    //public class Candidate
    //{
    //    public int ID { get; set; }
    //    public string Name { get; set; }
    //    public string Email { get; set; }
    //    public string Mobile { get; set; }
    //    public string Password { get; set; }
    //    public DateTime DateOfBirth { get; set; }
    //}

    //public class Exam
    //{
    //    public int ID { get; set; }
    //    public string Title { get; set; }
    //    public int Duration { get; set; }
    //    public int TotalMarks { get; set; }

    //    public ICollection<Question> Questions { get; set; }
    //}

    //public class Question
    //{
    //    public int ID { get; set; }
    //    public int ExamID { get; set; }
    //    public string QuestionText { get; set; }
    //    public string OptionA { get; set; }
    //    public string OptionB { get; set; }
    //    public string OptionC { get; set; }
    //    public string OptionD { get; set; }
    //    public string CorrectAnswer { get; set; }

    //    public Exam Exam { get; set; }
    //}

    //public class ExamResult
    //{
    //    public int ID { get; set; }
    //    public int ExamID { get; set; }
    //    public int CandidateID { get; set; }
    //    public int Score { get; set; }

    //    public Candidate Candidate { get; set; }
    //    public Exam Exam { get; set; }
    //}
}

﻿using ExamSystem.Data;
using ExamSystem.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace ExamSystem.Repositories
{
    public class CandidateRepository : ICandidateRepository
    {
        private readonly ApplicationDbContext _context;

        public CandidateRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        // Get all candidates
        public async Task<IEnumerable<Candidate>> GetAllCandidates()
        {
            return await _context.Candidate.ToListAsync();
        }

        // Get a candidate by ID
        public async Task<Candidate> GetCandidateById(int id)
        {
            return await _context.Candidate.FindAsync(id);
        }

        // Add a new candidate
        public async Task AddCandidate(Candidate candidate)
        {
            var passwordHasher = new PasswordHasher<Candidate>();
            candidate.Password = passwordHasher.HashPassword(candidate, candidate.Password); // Hash the password
            await _context.Candidate.AddAsync(candidate);
            await _context.SaveChangesAsync();
        }

        // Update an existing candidate
        public async Task UpdateCandidate(Candidate candidate)
        {
            // Hash password if provided
            if (!string.IsNullOrEmpty(candidate.Password))
            {
                var passwordHasher = new PasswordHasher<Candidate>();
                candidate.Password = passwordHasher.HashPassword(candidate, candidate.Password);
            }

            _context.Candidate.Update(candidate);
            await _context.SaveChangesAsync();
        }

        // Delete a candidate by ID
        public async Task DeleteCandidate(int id)
        {
            var candidate = await _context.Candidate.FindAsync(id);
            if (candidate != null)
            {
                _context.Candidate.Remove(candidate);
                await _context.SaveChangesAsync();
            }
        }

        // Get a candidate by email and password
        public async Task<Candidate> GetByEmailAndPassword(string email, string password)
        {
            var candidate = await _context.Candidate
                                          .FirstOrDefaultAsync(c => c.Email == email);

            if (candidate == null)
                return null;

            var passwordHasher = new PasswordHasher<Candidate>();
            var result = passwordHasher.VerifyHashedPassword(candidate, candidate.Password, password);

            return result == PasswordVerificationResult.Success ? candidate : null;
        }
    }
}

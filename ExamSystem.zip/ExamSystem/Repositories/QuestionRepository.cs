﻿using ExamSystem.Data;
using ExamSystem.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ExamSystem.Repositories
{
    public class QuestionRepository : IQuestionRepository
    {
        private readonly ApplicationDbContext _context;

        public QuestionRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        // Asynchronously get all questions by exam ID
        public async Task<List<Question>> GetQuestionsByExamId(int examId)
        {
            return await _context.Question
                .Where(q => q.ExamID == examId)
                .ToListAsync();  // Use ToListAsync for asynchronous operation
        }

        // Asynchronously get a question by ID
        public async Task<Question> GetQuestionById(int id)
        {
            return await _context.Question
                .FirstOrDefaultAsync(q => q.ID == id);  // Use FirstOrDefaultAsync for asynchronous operation
        }

        // Asynchronously add a new question
        public async Task AddQuestion(Question question)
        {
            await _context.Question.AddAsync(question);  // Use AddAsync for asynchronous operation
            await _context.SaveChangesAsync();            // Use SaveChangesAsync for asynchronous operation
        }

        // Asynchronously update an existing question
        public async Task UpdateQuestion(Question question)
        {
            _context.Question.Update(question);  // In-memory update does not need async
            await _context.SaveChangesAsync();    // Use SaveChangesAsync for asynchronous operation
        }

        // Asynchronously delete a question by ID
        public async Task DeleteQuestion(int id)
        {
            var question = await _context.Question.FindAsync(id);  // Use FindAsync for asynchronous operation
            if (question != null)
            {
                _context.Question.Remove(question);  // Asynchronous removal from context
                await _context.SaveChangesAsync();    // Use SaveChangesAsync for asynchronous operation
            }
        }
    }
}

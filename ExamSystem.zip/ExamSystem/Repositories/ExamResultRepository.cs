﻿using ExamSystem.Data;
using ExamSystem.Models;
using Microsoft.EntityFrameworkCore;

namespace ExamSystem.Repositories
{
    public class ExamResultRepository : IExamResultRepository
    {
        private readonly ApplicationDbContext _context;

        public ExamResultRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        // Asynchronous method to save exam result
        public async Task SaveResultAsync(int examId, int candidateId, int score)
        {
            var examResult = new ExamResult
            {
                ExamID = examId,
                CandidateID = candidateId,
                Score = score
            };

            await _context.ExamResult.AddAsync(examResult);  // Add result asynchronously
            await _context.SaveChangesAsync();  // Save changes asynchronously
        }

        // Asynchronous method to get all exam results
        public async Task<List<ExamResult>> GetAllResultsAsync()
        {
            return await _context.ExamResult.ToListAsync();  // Retrieve all results asynchronously
        }

        // Asynchronous method to get exam result by exam and candidate
        public async Task<ExamResult> GetResultByExamAndCandidateAsync(int examId, int candidateId)
        {
            return await _context.ExamResult
                                 .FirstOrDefaultAsync(r => r.ExamID == examId && r.CandidateID == candidateId);  // Query asynchronously
        }

        // Calculate score method (no async needed, but you can make it async if fetching data from DB)
        public async Task<int> CalculateScoreAsync(int examId, Dictionary<int, string> answers)
        {
            int score = 0;

            // Fetch the questions asynchronously from the database
            var questions = await _context.Question
                                          .Where(q => q.ExamID == examId)
                                          .ToListAsync();  // Asynchronous query to get questions

            // Iterate over the questions and calculate the score
            foreach (var question in questions)
            {
                if (answers.ContainsKey(question.ID) && answers[question.ID] == question.CorrectAnswer)
                {
                    score += 1; // Add 1 point for each correct answer
                }
            }

            return score;
        }


        // Asynchronous method to add a result
        public async Task AddExamResultAsync(ExamResult result)
        {
            await _context.ExamResult.AddAsync(result);  // Add result asynchronously
            await _context.SaveChangesAsync();  // Save changes asynchronously
        }

        // Asynchronous method to get exam result by candidate and exam
        public async Task<ExamResult> GetExamResultByCandidateAndExamAsync(int candidateId, int examId)
        {
            return await _context.ExamResult
                                 .FirstOrDefaultAsync(er => er.CandidateID == candidateId && er.ExamID == examId);  // Asynchronous query
        }
    }
}

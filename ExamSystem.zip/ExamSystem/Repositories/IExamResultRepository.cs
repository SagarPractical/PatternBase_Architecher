﻿using ExamSystem.Models;

namespace ExamSystem.Repositories
{
    public interface IExamResultRepository
    {
        Task SaveResultAsync(int examId, int candidateId, int score);  // Asynchronous method to save exam result
        Task<List<ExamResult>> GetAllResultsAsync();                   // Asynchronous method to get all results
        Task<ExamResult> GetResultByExamAndCandidateAsync(int examId, int candidateId);  // Asynchronous method to get result by exam and candidate
        Task<int> CalculateScoreAsync(int examId, Dictionary<int, string> answers); 
        Task AddExamResultAsync(ExamResult result);  // Asynchronous method to add exam result
        Task<ExamResult> GetExamResultByCandidateAndExamAsync(int candidateId, int examId); // Asynchronous method to get exam result
    }
}

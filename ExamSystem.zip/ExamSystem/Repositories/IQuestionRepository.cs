﻿using ExamSystem.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ExamSystem.Repositories
{
    public interface IQuestionRepository
    {
        Task<List<Question>> GetQuestionsByExamId(int examId);  // Ensure this returns Task<List<Question>>
        Task<Question> GetQuestionById(int questionId);         // Ensure this returns Task<Question>
        Task AddQuestion(Question question);                     // Add new question
        Task UpdateQuestion(Question question);                  // Update question details
        Task DeleteQuestion(int id);                             // Delete question
    }
}

﻿using ExamSystem.Models;

namespace ExamSystem.Repositories
{
    public interface ICandidateRepository
    {
        Task<IEnumerable<Candidate>> GetAllCandidates(); // Correct return type Task<List<Candidate>>
        Task<Candidate> GetCandidateById(int id); // Correct return type Task<Candidate>
        Task AddCandidate(Candidate candidate); // Correct return type Task
        Task UpdateCandidate(Candidate candidate); // Correct return type Task
        Task DeleteCandidate(int id); // Correct return type Task
        Task<Candidate> GetByEmailAndPassword(string email, string password); // Correct return type Task<Candidate>
    }


}

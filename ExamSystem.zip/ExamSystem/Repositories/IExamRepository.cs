﻿using ExamSystem.Models;

namespace ExamSystem.Repositories
{
    public interface IExamRepository
    {
        Task<List<Exam>> GetAllExams();  // Get all exams
        Task<Exam> GetExamById(int id);   // Get exam by ID
        Task AddExam(Exam exam);    // Add new exam
        Task UpdateExam(Exam exam); // Update exam details
        Task DeleteExam(int id);    // Delete exam
    }

}

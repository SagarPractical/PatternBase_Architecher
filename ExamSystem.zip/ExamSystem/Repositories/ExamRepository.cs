﻿using ExamSystem.Data;
using ExamSystem.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ExamSystem.Repositories
{
    public class ExamRepository : IExamRepository
    {
        private readonly ApplicationDbContext _context;

        public ExamRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        // Asynchronously fetch all exams
        public async Task<List<Exam>> GetAllExams()
        {
            return await _context.Exam.ToListAsync();  // Use ToListAsync for asynchronous operation
        }

        // Asynchronously fetch an exam by ID
        public async Task<Exam> GetExamById(int id)
        {
            return await _context.Exam.FirstOrDefaultAsync(e => e.ID == id);  // Use FirstOrDefaultAsync for asynchronous operation
        }

        // Asynchronously add a new exam
        public async Task AddExam(Exam exam)
        {
            await _context.Exam.AddAsync(exam);  // Use AddAsync for asynchronous operation
            await _context.SaveChangesAsync();    // Use SaveChangesAsync for asynchronous operation
        }

        // Asynchronously update an existing exam
        public async Task UpdateExam(Exam exam)
        {
            _context.Exam.Update(exam);  // This is an in-memory operation, no need for async here
            await _context.SaveChangesAsync();    // Use SaveChangesAsync for asynchronous operation
        }

        // Asynchronously delete an exam by ID
        public async Task DeleteExam(int id)
        {
            var exam = await _context.Exam.FindAsync(id);  // Use FindAsync for asynchronous operation
            if (exam != null)
            {
                _context.Exam.Remove(exam);  // Asynchronous removal from context
                await _context.SaveChangesAsync();  // Use SaveChangesAsync for asynchronous operation
            }
        }
    }
}

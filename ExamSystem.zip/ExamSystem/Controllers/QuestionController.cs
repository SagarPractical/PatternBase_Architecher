﻿using ExamSystem.Data;
using ExamSystem.Models;
using ExamSystem.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace ExamSystem.Controllers
{
    public class QuestionController : Controller
    {
        private readonly IExamRepository _examRepository;  // Add dependency for exams
        private readonly IQuestionRepository _questionRepository;

        public QuestionController(IExamRepository examRepository, IQuestionRepository questionRepository)
        {
            _examRepository = examRepository;
            _questionRepository = questionRepository;
        }

        [HttpGet]
        [Route("Index")]
        public async Task<IActionResult> Index(int? examId)
        {
            // Get all exams to populate the dropdown
            List<Exam> exams = await GetAllQueViewBag();

            List<Question> questions;

            if (examId.HasValue && examId.Value != 0)
            {
                // If an exam is selected (examId is not null or 0), filter questions by the selected exam
                questions = await _questionRepository.GetQuestionsByExamId(examId.Value);
            }
            else
            {
                // If no exam is selected (or default option is chosen), show no questions or all questions
                questions = new List<Question>();
            }

            return View(questions);
        }



        private async Task<List<Exam>> GetAllQueViewBag()
        {
            var exams = await _examRepository.GetAllExams();
            ViewBag.ExamList = new SelectList(exams, "ID", "Title");
            return exams;
        }


        // GET: Create a new question
        public async Task<IActionResult> CreateQuestion()
        {
            await GetAllQueViewBag();
            return View(new Question());
        }

        // POST: Create a new question
        [HttpPost]
        public async Task<IActionResult> CreateQuestion(Question question)
        {
            if (ModelState.IsValid)
            {
                await _questionRepository.AddQuestion(question);
                return RedirectToAction("Index", new { examId = question.ExamID });
            }

            // If the model is invalid, reload the exam list in case the user needs to correct their input
            await GetAllQueViewBag();
            return View(question);
        }

        // GET: Edit a question
        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            // Retrieve the question by its ID
            var question = await _questionRepository.GetQuestionById(id);

            await GetAllQueViewBag();

            if (question == null)
            {
                return NotFound();
            }

            return View(question);
        }

        // POST: Edit a question
        [HttpPost]
        public async Task<IActionResult> Edit(int id, Question question)
        {
            if (ModelState.IsValid)
            {
                question.ID = id;
                await _questionRepository.UpdateQuestion(question);
                return RedirectToAction("Index", new { examId = question.ExamID });
            }

            var exams = await _examRepository.GetAllExams();
            ViewBag.ExamList = new SelectList(exams, "ID", "Title", question.ExamID);

            return View(question);
        }

        // GET: Delete a question
        public async Task<IActionResult> Delete(int id)
        {
            var question = await _questionRepository.GetQuestionById(id);
            if (question == null)
            {
                return NotFound();
            }

            return View(question);
        }

        // POST: Delete a question
        [HttpPost]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            await _questionRepository.DeleteQuestion(id);
            return RedirectToAction("Index");
        }


        //// GET: Create a new question
        //public async Task<IActionResult> CreateQuestion()
        //{
        //    // Get the list of available exams
        //    var exams = await _examRepository.GetAllExams();

        //    // Check if exams are available
        //    if (exams == null || !exams.Any())
        //    {
        //        // Handle the case where there are no exams available
        //        ModelState.AddModelError(string.Empty, "No exams available. Please add an exam first.");
        //        return View(new Question());
        //    }

        //    // Prepare a view model for creating a question (dropdown list for exams)
        //    ViewBag.ExamList = new SelectList(exams, "ID", "Title");

        //    var model = new Question();
        //    return View(model);
        //}

        //// POST: Create a new question
        //[HttpPost]
        //public async Task<IActionResult> CreateQuestion(Question question)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        // Save the question after validation
        //        await _questionRepository.AddQuestion(question);
        //    }

        //    // If the model is invalid, reload the exam list in case the user needs to correct their input
        //    var exams = await _examRepository.GetAllExams();
        //    ViewBag.ExamList = new SelectList(exams, "ID", "Title");
        //    return RedirectToAction("Login", "Account");
        //}
    }
}

﻿using ExamSystem.Models;
using ExamSystem.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace ExamSystem.Controllers
{
    public class ExamController : Controller
    {
        private readonly IExamRepository _examRepository;
        private readonly IQuestionRepository _questionRepository;
        private readonly IExamResultRepository _examResultRepository;

        public ExamController(IExamRepository examRepo, IQuestionRepository questionRepo, IExamResultRepository examResultRepo)
        {
            _examRepository = examRepo;
            _questionRepository = questionRepo;
            _examResultRepository = examResultRepo;
        }


        public async Task<IActionResult> Index()
        {
            var exams = await _examRepository.GetAllExams();
            return View(exams);
        }

        public async Task<IActionResult> ExamList()
        {
            var exams = await _examRepository.GetAllExams();
            return View(exams);
        }

        [HttpGet]
        public IActionResult CreateExam()
        {
            var model = new Exam();
            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> CreateExam(Exam exam)
        {
            if (ModelState.IsValid)
            {
                await _examRepository.AddExam(exam);
            }
            return RedirectToAction("Login", "Account");
        }

        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            var exam = await _examRepository.GetExamById(id);
            return View(exam);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(int id, Exam exam)
        {
            if (ModelState.IsValid)
            {
                exam.ID = id;
                await _examRepository.UpdateExam(exam);
                return RedirectToAction("Index");
            }
            return View(exam);
        }

        [HttpGet]
        public async Task<IActionResult> Delete(int id)
        {
            await _examRepository.DeleteExam(id);
            return RedirectToAction("Index");
        }
    }
}

﻿using ExamSystem.Models;
using ExamSystem.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace ExamSystem.Controllers
{
    public class ExamAttemptController : Controller
    {
        private readonly IExamRepository _examRepository;
        private readonly IQuestionRepository _questionRepository;
        private readonly IExamResultRepository _examResultRepository;
        private readonly ICandidateRepository _candidateRepository;

        public ExamAttemptController(
            IExamRepository examRepository,
            IQuestionRepository questionRepository,
            IExamResultRepository examResultRepository,
            ICandidateRepository candidateRepository)
        {
            _examRepository = examRepository;
            _questionRepository = questionRepository;
            _examResultRepository = examResultRepository;
            _candidateRepository = candidateRepository;
        }

        // Display Exam List (for logged-in candidates)
        [HttpGet]
        public async Task<IActionResult> ExamList()
        {
            var candidateId = HttpContext.Session.GetInt32("CandidateID");

            if (!candidateId.HasValue)
            {
                return RedirectToAction("Login", "Account");
            }

            var exams = await _examRepository.GetAllExams();
            return View(exams);  // Return the exam list view
        }


        // Display Exam List (for logged-in candidates)
        [HttpGet]
        public async Task<IActionResult> TimeFinished()
        {
            return View(); 
        }

        // Display Exam Attempt Form (when candidate selects an exam)
        [HttpGet]
        public async Task<IActionResult> StartExam(int examId)
        {
            var exam = await _examRepository.GetExamById(examId);
            // Get questions related to the selected exam
            var questions = await _questionRepository.GetQuestionsByExamId(examId);

            var model = new ExamAttemptViewModel
            {
                Exam = exam,
                Questions = questions,
                CurrentQuestionIndex = 0  // Start with the first question
            };

            return View("ExamAttempt", model);  // Return the Exam Attempt form view (ExamAttempt.cshtml)
        }

        // Handle Exam Submission
        [Route("ExamAttempt/SubmitExam")]
        [HttpPost]
        public async Task<IActionResult> SubmitExam(ExamAttemptViewModel model, Dictionary<int, string> Answers)
        {
            if (ModelState.IsValid)
            {
                int score = 0;

                var Questions = await _questionRepository.GetQuestionsByExamId(model.Exam.ID);
                if (Questions != null)
                {
                    // Calculate score by checking answers
                    foreach (var question in Questions)
                    {
                        // Get the selected answer for each question from the Answers dictionary
                        var answer = Answers.ContainsKey(question.ID) ? Answers[question.ID] : null;

                        // If the selected answer is correct, increment score
                        if (answer == question.CorrectAnswer)
                        {
                            score++;  // Increase score for correct answers
                        }
                    }
                }


                // Get the logged-in candidate
                var candidateId = HttpContext.Session.GetInt32("CandidateID");
                var candidate = await _candidateRepository.GetCandidateById(candidateId.GetValueOrDefault());

                if (candidate != null)
                {
                    // Save the exam result to the ExamResult table
                    var examResult = new ExamResult
                    {
                        ExamID = model.Exam.ID,
                        CandidateID = candidate.ID,
                        Score = score
                    };
                    await _examResultRepository.AddExamResultAsync(examResult);
                }

                // Redirect to result page
                return RedirectToAction("ExamResult", new { examId = model.Exam.ID });
            }

            // If the model is invalid, return the same view with validation errors
            return View("ExamAttempt", model);
        }

        // Display Exam Results (after submission)
        [HttpGet]
        public async Task<IActionResult> ExamResult(int examId)
        {
            var candidateId = HttpContext.Session.GetInt32("CandidateID");
            var candidate = await _candidateRepository.GetCandidateById(candidateId.GetValueOrDefault());

            if (candidate == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var result = await _examResultRepository.GetExamResultByCandidateAndExamAsync(candidateId.GetValueOrDefault(), examId);

            if (result == null)
            {
                return NotFound();
            }

            var exam = await _examRepository.GetExamById(examId);
            if (exam == null)
            {
                return NotFound();
            }

            var model = new ExamResultViewModel
            {
                CandidateName = candidate.Name,
                ExamTitle = exam.Title,
                Score = result.Score,
                TotalMarks = exam.TotalMarks
            };

            return View(model);
        }

    }
}

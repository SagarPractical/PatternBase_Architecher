﻿using ExamSystem.Data;
using ExamSystem.Models;
using ExamSystem.Repositories;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace ExamSystem.Controllers
{
    public class CandidateController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly ICandidateRepository _candidateRepository;
        private readonly PasswordHasher<Candidate> _passwordHasher;
        public CandidateController(ApplicationDbContext context, ICandidateRepository candidateRepository)
        {
            _context = context;
            _candidateRepository = candidateRepository;
            _passwordHasher = new PasswordHasher<Candidate>();
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var candidates = await _candidateRepository.GetAllCandidates();
            return View(candidates);
        }

        // Create
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(Candidate candidate)
        {
            if (ModelState.IsValid)
            {
                // Hash the password before saving
                var passwordHasher = new PasswordHasher<Candidate>();
                candidate.Password = passwordHasher.HashPassword(candidate, candidate.Password);

                // Add the candidate to the context
                _context.Add(candidate);
                await _context.SaveChangesAsync();

                return RedirectToAction("Login", "Account");
            }

            // If the model is invalid, return the same view to show validation errors
            return View(candidate);
        }

        // Edit
        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            // Retrieve the candidate by id
            var candidate = await _candidateRepository.GetCandidateById(id);
            candidate.Password = _passwordHasher.HashPassword(candidate, candidate.Password);

            if (candidate == null)
            {
                return NotFound();  // If the candidate is not found, return 404
            }

            return View(candidate);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(Candidate candidate)
        {
            if (ModelState.IsValid)
            {
                // Retrieve the existing candidate from the database by ID
                var existingCandidate = await _candidateRepository.GetCandidateById(candidate.ID);

                if (existingCandidate == null)
                {
                    return NotFound();  // If the candidate does not exist, return 404
                }

                // Update candidate details (except password)
                existingCandidate.Name = candidate.Name;
                existingCandidate.Email = candidate.Email;
                existingCandidate.Mobile = candidate.Mobile;  
                existingCandidate.DateOfBirth = candidate.DateOfBirth;

                // Save changes to the database
                _context.Update(existingCandidate);
                await _context.SaveChangesAsync();

                return RedirectToAction("Index");  // Redirect to index after updating
            }

            // If model is invalid, return the same view to show validation errors
            return View(candidate);
        }


        // Delete
        [HttpGet]
        public async Task<IActionResult> Delete(int id)
        {
            var candidate = await _candidateRepository.GetCandidateById(id);
            if (candidate == null)
            {
                return NotFound();  // If the candidate is not found, return 404
            }

            return View(candidate);
        }

        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var candidate = await _candidateRepository.GetCandidateById(id);
            if (candidate == null)
            {
                return NotFound();  // If the candidate is not found, return 404
            }

            // Remove the candidate from the context and save changes
            _context.Candidate.Remove(candidate);
            await _context.SaveChangesAsync();

            return RedirectToAction("Index");
        }

    }

}

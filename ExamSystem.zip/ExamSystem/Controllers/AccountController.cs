﻿using Microsoft.AspNetCore.Mvc;
using ExamSystem.Models;
using ExamSystem.Repositories;

namespace ExamSystem.Controllers
{

    public class AccountController : Controller
    {
        private readonly ICandidateRepository _candidateRepository;

        public AccountController(ICandidateRepository candidateRepository)
        {
            _candidateRepository = candidateRepository;
        }

        // Login GET
        public IActionResult Login() => View();

        // Login POST
        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                // Attempt to get the candidate by email and password
                var candidate = await _candidateRepository.GetByEmailAndPassword(model.Email, model.Password);

                if (candidate != null)
                {
                    // Candidate found, set session or authentication token here
                    // Example: store candidate's ID or token in session/cookie
                    HttpContext.Session.SetInt32("CandidateID", candidate.ID);
                    return RedirectToAction("ExamList", "Exam");
                }

                // If no candidate is found, add an error to the model state
                ModelState.AddModelError("", "Invalid login attempt.");
            }

            // If model state is invalid, or login failed, return to the view with the error
            return View();
        }

        // Logout action
        [HttpPost]
        public IActionResult Logout()
        {
            // Clear the session to log the user out
            HttpContext.Session.Remove("CandidateID");
            return RedirectToAction("Login", "Account"); // Or wherever you want to redirect after logout
        }
    }

}
